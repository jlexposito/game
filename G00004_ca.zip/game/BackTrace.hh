
#ifndef BackTrace_hh
#define BackTrace_hh

#include <iostream>
using namespace std;


struct BackTrace {
    void static print (ostream& os = cerr);
};

#endif
