
title:      PacMan

authors:    Jordi Petit
            Salvador Roura
            Omer Giménez
            Mario G. Munzón

contact:    jpetit@lsi.upc.edu

(c) Universitat Politècnica de Catalunya, 2012

